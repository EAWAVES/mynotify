<?php

$dsn='mysql:host=localhost;dbname=tourismdb';
$username='root';
$password='';
$option=[];

try{
$connection = new PDO($dsn,$username,$password,$option);
}catch(PDOException $e){

}
?>